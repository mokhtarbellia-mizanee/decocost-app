Android wrapper uses Capacitor config in the project root. APK build workflow is in .github/workflows/build-android.yml.
